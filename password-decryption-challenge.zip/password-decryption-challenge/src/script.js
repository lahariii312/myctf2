document.getElementById('submit-btn').addEventListener('click', checkPassword);

function checkPassword() {
    const passwordInput = document.getElementById('password-input').value;
    const correctPassword = decryptPassword(); // Use this hint ;)

    if (passwordInput === correctPassword) {
        document.getElementById('flag-content').textContent = "FLAG{password_cracked_456}";
        document.getElementById('flag').style.display = "block";
    } else {
        alert('Incorrect password. Try again!');
    }
}

// Simulating a decryption function to add complexity
function decryptPassword() {
    return atob("c2VjcmV0X3Bhc3N3b3Jk"); // Base64 decoded: 'secret_password'
}

// Developer hint:
// The password is hidden in plain sight but slightly encrypted!
